class soError extends Error {
    constructor(name, message, statusCode, context) {
      super(message)
      this.statusCode = statusCode
      this.context = context
      this.name = name
  
      Error.captureStackTrace(this, this.constructor)
    }
  }
  
   
  
  module.exports = soError