let getLogger = loggerConfig => {
  const winston = require('winston')

  const console = winston.transports.Console
  const { LoggingWinston } = require('@google-cloud/logging-winston')
  const gcpTransport = new LoggingWinston({
    projectId: loggerConfig.KEY.project_id,
    credentials: loggerConfig.KEY,
    level: loggerConfig.LEVEL,
    logName: globalAppName + '.log',
  })
  winston.add(new console(), { level: process.env.Log_Level })
  winston.add(gcpTransport)
  return winston
}

module.exports = getLogger
