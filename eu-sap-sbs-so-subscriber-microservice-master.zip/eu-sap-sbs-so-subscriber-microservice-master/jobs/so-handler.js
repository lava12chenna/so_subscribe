const subscriber = require('./register-subscriber')
const so_save_ser = require('../services/save-so')
const so_handler = async so_resp => {
  // handle the message and pass it on to different services

  // save_so service will take care to fetch schedule lines if needed
  // and save response to database
  let confirmation = JSON.parse(so_resp)
  try {
    let so_save = await so_save_ser(confirmation)
    return so_save
  } catch (e) {
    console.error(e)
    throw e
  }
}
// start the job
subscriber(so_handler)
