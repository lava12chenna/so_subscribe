const pjson = require('../package.json')
globalAppName = pjson.name
const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)
const pubsubConfig = serviceConfig.PUBSUB
const topic = serviceConfig.PUBSUB.TOPIC
const source_topic = require('../config/pubsub-config')(pubsubConfig,topic)
// register the subscription here so we can use this to pass message to our handler
// place correct subscription name from config
function registerSubscriber(so_handler) {
  const subscription = source_topic.subscription(pubsubConfig.SUBSCRIPTION)
  /*, {
    autoAck: true,
  })*/

  subscription.on('message', message => {
    console.log(`Message received:: ${message.id}`)
    let so_resp = message.data.toString('utf-8')
    so_handler(so_resp)
      .then(r => {
        console.log('inside registerthen')
        message.ack()
      })
      .catch(e => {
        console.log('inside registercatch')
        console.error(e)
      })
    //message.ack()
  })

  subscription.on('error', err => {
    console.error(err)
  })
}
module.exports = registerSubscriber
