
const soError = require('../utils/so-error')
let publishSo = async (confirmedSoKey, topic) => {
    try {
      const databuffer = Buffer.from(JSON.stringify(confirmedSoKey))
      let ack = await topic.publish(databuffer)
  
   
  
      return ack
    } catch (e) {
      console.log(e)
      const message =
        e.message || 'Could not publish the Sales Order. Have to close the SO'
      throw new soError('PubSub', message, 500, 'PublishSoError')
    }
  }
  
   
  
  module.exports = publishSo