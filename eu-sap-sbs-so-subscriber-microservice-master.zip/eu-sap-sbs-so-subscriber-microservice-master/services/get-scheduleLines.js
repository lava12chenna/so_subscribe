let axios = require('axios');
const pjson = require('../package.json')
globalAppName = pjson.name
const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

const headers = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'x-csrf-token': 'fetch',
  }
  let endpoint = serviceConfig.SO_SERVICE;


let scheduleLineInfo = async (soNo)=>{ 
  
    try {
    var resp = await axios({
      url: endpoint.concat(`/A_SalesOrderItem?%24filter=SalesOrder%20eq%20%27${soNo}%27&%24expand=to_ScheduleLine`),
      method: 'get',
      headers: headers,
      auth: creds,
    });
    await console.log(resp.data.d.results);
    return resp;
}
catch (error) {
    console.log('error while fetching schedule lines');
    throw error
  }


}

module.exports = scheduleLineInfo;

