let axios = require('axios')

const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

const headers = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'x-csrf-token': 'fetch',
}
let endpoint = serviceConfig.SO_SERVICE
let sapClient = serviceConfig.SAP_CLIENT

const creds = {
  username: serviceConfig.SO_SERVICE_USER,
  password: serviceConfig.SO_SERVICE_PWD,
}

let schLineInfo = async soNo => {
  try {
    let resp = await axios({
      url: endpoint.concat(
        `/A_SalesOrder('${soNo}')/to_Item?$expand=to_ScheduleLine&${sapClient}`,
      ),
      method: 'get',
      headers: headers,
      auth: creds,
    })
    let itemResp = resp.data.d.results
    let quantity = 0
    // loop at sales order item
    let soDbLines = itemResp.map(soLine => {
      let soLineEntry = {}
      //collect SO confirmation number
      soLineEntry.SO_confirmation_no = soLine.SalesOrder
      // collect the SO line number and save to SO line data
      soLineEntry.SO_line_no = soLine.SalesOrderItem
      // Get the item category from SO item and save to SO line data
      soLineEntry.SO_item_category = soLine.SalesOrderItemCategory
      soLineEntry.SO_schedule_line_doc = JSON.stringify(
        soLine.to_ScheduleLine.results,
      )
      // loop for so item schedule lines
      soLine.to_ScheduleLine.results.forEach(schLine => {
        //collect the confirmed quantity and save to SO line data
        quantity = quantity + schLine.ConfdOrderQtyByMatlAvailCheck
      })
      //soLineDataObj.data.confirmedquantity = quantity;
      quantity = 0
      return soLineEntry
    })

    let soLineDataObj = {
      table: 'so-sto.SO_Line_Details',
      data: soDbLines,
    }

    return soLineDataObj
  } catch (error) {
    console.log('error while fetching schedule lines')
    throw error
  }
}

module.exports = schLineInfo
