let axios = require('axios')

const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

const headers = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'x-csrf-token': 'fetch',
}
let endpoint = serviceConfig.SO_SERVICE

const creds = {
  username: serviceConfig.SO_SERVICE_USER,
  password: serviceConfig.SO_SERVICE_PWD,
}

module.exports = async(soNo) => {
  try {
    var resp = await axios({
      url: endpoint.concat(`/A_SalesOrder('${so}')/to_Item?$expand=to_ScheduleLine&sap-client=720`),
      method: 'get',
      headers: headers,
      auth: creds,
    })
    var itemResp = JSON.stringify(resp.data.d.results);
    var quantity = 0;
    // loop at sales order item
    var soDbLines = soItemArr.map(soLine => {
      var soLineEntry = {};
      //collect SO confirmation number
      soLineEntry.SO_confirmation_no = soLine.SalesOrder;
      // collect the SO line number and save to SO line data
      soLineEntry.SO_line_no = soLine.SalesOrderItem;
      // Get the item category from SO item and save to SO line data
      soLineEntry.SO_item_category = soLine.SalesOrderItemCategory;
      soLineEntry.SO_schedule_line_doc = JSON.stringify(soLine.to_ScheduleLine.results);
      // loop for so item schedule lines 
      soLine.to_ScheduleLine.results.forEach((schLine) => {
        //collect the confirmed quantity and save to SO line data
        quantity = quantity + schLine.ConfdOrderQtyByMatlAvailCheck;

      });
      //soLineDataObj.data.confirmedquantity = quantity;
      quantity = 0;
      return soLineEntry;
    });

    let soLineDataObj = {
      table: 'so-sto.SO_Line_Details',
      data: soDbLines,
    }

    return soLineDataObj;
  } catch (error) {
    console.log('error while fetching schedule lines')
    throw error
  }

}

//module.exports = schLineInfo
