let axios = require('axios')

const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

const headers = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'x-csrf-token': 'fetch',
}
let endpoint = serviceConfig.SO_SERVICE

const creds = {
  username: serviceConfig.SO_SERVICE_USER,
  password: serviceConfig.SO_SERVICE_PWD,
}

module.exports = (soItemArr) => {
  var quantity = 0;
  
  // loop at sales order item
  var soDbLines = soItemArr.map(soLine => {
       var soLineEntry = {};
    //collect SO confirmation number
    soLineEntry.SO_confirmation_no = soLine.SalesOrder;
    // collect the SO line number and save to SO line data
    soLineEntry.SO_line_no = soLine.SalesOrderItem;
    // Get the item category from SO item and save to SO line data
    soLineEntry.SO_item_category = soLine.SalesOrderItemCategory;
    soLineEntry.SO_schedule_line_doc = JSON.stringify(soLine.to_ScheduleLine.results);
    // loop for so item schedule lines 
    soLine.to_ScheduleLine.results.forEach((schLine) => {
      //collect the confirmed quantity and save to SO line data
      quantity = quantity + schLine.ConfdOrderQtyByMatlAvailCheck;

    });
    //soLineDataObj.data.confirmedquantity = quantity;
    quantity = 0;
    return soLineEntry;
  });

  let soLineDataObj = {
    table: 'so-sto.SO_Line_Details',
    data : soDbLines,
  }

   return soLineDataObj;
  /*try {
    var resp = await axios({
      url: endpoint.concat(
        `/A_SalesOrderItem?%24filter=SalesOrder%20eq%20%27${soNo}%27&%24expand=to_ScheduleLine`,
      ),
      method: 'get',
      headers: headers,
      auth: creds,
    })
    await console.log(resp.data.d.results)
    return resp
  } catch (error) {
    console.log('error while fetching schedule lines')
    throw error
  }*/
}

//module.exports = schLineInfo
