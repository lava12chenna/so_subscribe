//TODO Save the SO service. Save the confirmtion to so_confirmations

const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

let db = require('../config/err-db-config')(serviceConfig.DB)
let dbInsert = require('./db_insert.js')

let saveSo = async message => {
  let soResp = message
  let soNo = soResp.SalesOrder
  let soType = soResp.SalesOrderType
  let customer = soResp.SoldToParty
  //TODO fix reference number and created time
  let dataObj = {
    table: 'so-sto.SO_Confirmations',
    data: {
      SO_ref_no: 'REF1',
      SO_confirmation_no: soNo,
      SO_document: JSON.stringify(message),
      SO_type: soType,
      SO_customer_no: customer,
      SO_x_company_eligible: null,
    },
  }

  if (soType === ('Y002' || 'ZGB1')) {
    // make the x eligiblity true

    dataObj.data.SO_x_company_eligible = true

    // call schedule line service to pick the schedule line info
    let scheduleLineInfo = require('./get-scheduleLines')
    // schedule line info should get saved by calling below function
   // Below statement relavent, if so response has schedule line
    //  var soLineDataObj = scheduleLineInfo(soResp.to_Item.results);
        var soLineDataObj = scheduleLineInfo(soNo);
  } else {
    dataObj.data.SO_x_company_eligible = false
  }

  dbInsert(db, dataObj).then(res => {
    if (res === 1) {
      console.log('db insert failed')
    }
  })

  if (soLineDataObj ) {
  dbInsert(db, soLineDataObj).then(res => {
    if (res === 1) {
      console.log('db insert failed')
    }
  })
}
  return 'done'
}

module.exports = saveSo
