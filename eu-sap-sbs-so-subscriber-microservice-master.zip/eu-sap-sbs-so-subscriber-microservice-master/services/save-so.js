//TODO Save the SO service. Save the confirmtion to so_confirmations
const pjson = require('../package.json')
globalAppName = pjson.name
const appenv = require('../config/config').getAppConfig()
const serviceConfig = appenv.getServiceCreds(globalAppName)

let db = require('../config/err-db-config')(serviceConfig.DB);
let dbInsert = require('./db_insert.js');

let saveSo = ((message)=>{
var soResp = JSON.parse(message);
var soNo = soResp.d.SalesOrder;
var soType = soResp.d.SalesOrderType;

if (soType === 'Y001' || 'OR') {
    let dataObj = {
       table: 'so-sto.SO_Confirmations',
       data: {
         SO_ref_no : ['REF1'],
         SO_confirmation_no : [soNo],
         SO_document : message,
         SO_type : [soType],
         SO_customer_no : [soResp.d.SoldToParty],
         SO_x_company_eligible : false
       }

    };
   dbInsert(db,dataObj).then((res)=>{
     if (res === 1) {
         console.log('db insert failed');
     }
   });
} else if(soType === 'Y002' || 'ZGB1'){
    // call schedule line service to pick the schedule line info
    let scheduleLineInfo = require('get-scheduleLines');
// schedule line info should get saved by calling below function
    let sch_lines = scheduleLineInfo(soNO);
}

});

module.exports = saveSo;