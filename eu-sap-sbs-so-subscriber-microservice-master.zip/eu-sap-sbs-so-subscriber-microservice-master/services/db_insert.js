const success = 0;
const failed = 1;
let insertEntry = async (db, dataObj)=>{
    try {
        let result = await db(dataObj.table).insert(dataObj.data);
        return success;
    } catch (e) {
        console.log(`DBinsert error: ${e}`);
        return failed;
    }
}

module.exports = insertEntry;