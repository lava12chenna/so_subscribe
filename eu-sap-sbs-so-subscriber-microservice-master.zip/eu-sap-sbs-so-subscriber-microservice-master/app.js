var Arr1 = [1, 2, 3, 4] ;

var Arr2 = [];
var a = 0;

Arr1.forEach((e)=>{
    a = e + 1;
    Arr2.push(a);
})


console.log(Arr2);

