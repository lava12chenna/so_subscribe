const { PubSub } = require('@google-cloud/pubsub')

let getPubSubTopic = (pubsubConfig, topic) => {
  const pubsub = new PubSub({
    projectId: pubsubConfig.KEY.project_id,
    credentials: pubsubConfig.KEY,
  })

  return pubsub.topic(topic)

}

module.exports = getPubSubTopic
