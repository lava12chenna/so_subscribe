const { PubSub } = require('@google-cloud/pubsub')
let getPubSubTopic = pubsubConfig => {
  const pubsub = new PubSub({
    projectId: pubsubConfig.KEY.project_id,
    credentials: pubsubConfig.KEY,
  })

  return pubsub.topic(pubsubConfig.TOPIC)
}

module.exports = getPubSubTopic
