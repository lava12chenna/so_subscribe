const cfenv = require('cfenv')
let environment = process.env.NODE_ENV
let appenv = ''
if (environment.trim() === 'local') {
  let path = require('path')
  let configFilename = path.join(
    __dirname,
    '..',
    'config',
    environment.trim().concat('.json'),
  )
  const envoptions = {
    vcapFile: configFilename,
  }
  appenv = cfenv.getAppEnv(envoptions)
} else {
  appenv = cfenv.getAppEnv()
}

let checkAppEnv = appenv => {
  if (!appenv) {
    console.error('Local configuration Or Cloud configuration is not found')
    throw new Error('App Cofiguration not found')
  }
  return appenv
}

let getAppConfig = () => {
  return checkAppEnv(appenv)
}

let getServiceConfig = serviceName => {
  const creds = checkAppEnv(appenv).getServiceCreds(serviceName)
  return creds
}

module.exports = {
  getAppConfig: getAppConfig,
  getServiceConfig: getServiceConfig,
}
