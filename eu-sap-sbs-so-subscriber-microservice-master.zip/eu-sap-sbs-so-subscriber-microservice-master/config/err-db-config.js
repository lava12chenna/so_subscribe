const getErrDb = dbconfig => {
  return require('knex')({
    client: 'pg',
    connection: dbconfig,
  })
}

module.exports = getErrDb
